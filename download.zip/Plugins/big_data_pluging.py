from airflow.plugins_manager import AirflowPlugin

class BigDataPlugin(AirflowPlugin):
    name = " big_data_plugin"